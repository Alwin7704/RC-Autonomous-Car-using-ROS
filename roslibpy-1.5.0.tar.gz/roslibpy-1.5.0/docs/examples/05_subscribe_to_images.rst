Subscribe to images
===================

This example shows how to subscribe to a topic of images
using the built-in ``sensor_msgs/CompressedImage`` message type.

.. literalinclude :: 05_subscribe_to_images.py
   :language: python
