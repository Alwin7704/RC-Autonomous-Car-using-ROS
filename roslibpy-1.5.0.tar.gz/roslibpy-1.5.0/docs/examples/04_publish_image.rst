Publish images
==============

This example shows how to publish images using the
built-in ``sensor_msgs/CompressedImage`` message type.

.. literalinclude :: 04_publish_image.py
   :language: python
