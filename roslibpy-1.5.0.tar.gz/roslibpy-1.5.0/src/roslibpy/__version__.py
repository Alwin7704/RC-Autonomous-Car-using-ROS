# 72 6F 73 6C 69 62 70 79
# 47 72 61 6D 61 7A 69 6F  4B 6F 68 6C 65 72  52 65 73 65 61 72 63 68

__title__ = "roslibpy"
__description__ = "Python ROS Bridge library."
__url__ = "https://github.com/gramaziokohler/roslibpy"
__version__ = "1.5.0"
__author__ = "Gramazio Kohler Research"
__author_email__ = "gramaziokohler@arch.ethz.ch"
__license__ = "MIT license"
__copyright__ = "Copyright 2018 Gramazio Kohler Research"
