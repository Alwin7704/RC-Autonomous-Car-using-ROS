
Authors
=======

* Gramazio Kohler Research `@gramaziokohler <https://github.com/gramaziokohler>`_
* Gonzalo Casas <casas@arch.ethz.ch> `@gonzalocasas <https://github.com/gonzalocasas>`_
* Mathias Lüdtke `@ipa-mdl <https://github.com/ipa-mdl>`_
* Beverly Lytle `@beverlylytle <https://github.com/beverlylytle>`_
* Alexis Jeandeau `@jeandeaual <https://github.com/jeandeaual>`_
* Hiroyuki Obinata `@obi-t4 <https://github.com/obi-t4>`_
* Pedro Pereira `@MisterOwlPT <https://github.com/MisterOwlPT>`_
* Domenic Rodriguez `@DomenicP <https://github.com/DomenicP>`_
