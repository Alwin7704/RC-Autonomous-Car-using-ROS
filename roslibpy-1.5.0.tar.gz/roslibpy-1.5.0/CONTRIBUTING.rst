Contributor's Guide
===================

Contributions are always welcome and greatly appreciated!

Code contributions
------------------

We love pull requests from everyone! Here's a quick guide to improve the code:

1. Fork `the repository <https://github.com/gramaziokohler/roslibpy>`_ and clone the fork.
2. Create a virtual environment using your tool of choice (e.g. ``virtualenv``, ``conda``, etc).
3. Install development dependencies:

::

    pip install -r requirements-dev.txt

4.  Run the docker container:

::

    docker run -d -p 9090:9090 --name roslibpy_integration_tests gramaziokohler/integration-tests-bridge /bin/bash -c "roslaunch /integration-tests.launch"

5. Make sure all tests pass:

::

    invoke test

6. Start making your changes to the **main** branch (or branch off of it).
7. Make sure all tests still pass:

::

    invoke test

8. Stop your docker container:

::

    docker stop roslibpy_integration_tests

9. Add yourself to ``AUTHORS.rst``.
10. Commit your changes and push your branch to GitHub.
11. Create a `pull request <https://help.github.com/articles/about-pull-requests/>`_ through the GitHub website.


During development, use `pyinvoke <http://docs.pyinvoke.org/>`_ tasks on the
command prompt to ease recurring operations:

* ``invoke clean``: Clean all generated artifacts.
* ``invoke check``: Run various code and documentation style checks.
* ``invoke docs``: Generate documentation.
* ``invoke test``: Run all tests and checks in one swift command.
* ``invoke``: Show available tasks.


Documentation improvements
--------------------------

We could always use more documentation, whether as part of the
introduction/examples/usage documentation or API documentation in docstrings.

Documentation is written in `reStructuredText <http://docutils.sourceforge.net/rst.html>`_
and use `Sphinx <http://sphinx-doc.org/index.html>`_ to generate the HTML output.

Once you made the documentation changes locally, run the documentation generation::

    invoke docs


Bug reports
-----------

When `reporting a bug <https://github.com/gramaziokohler/roslibpy/issues>`_
please include:

    * Operating system name and version.
    * ROS version.
    * Any details about your local setup that might be helpful in troubleshooting.
    * Detailed steps to reproduce the bug.

Feature requests and feedback
-----------------------------

The best way to send feedback is to file an issue on
`Github <https://github.com/gramaziokohler/roslibpy/issues>`_. If you are proposing a feature:

* Explain in detail how it would work.
* Keep the scope as narrow as possible, to make it easier to implement.

